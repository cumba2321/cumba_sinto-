<!DOCTYPE html>
<html>
<head>
    <title>My Website</title>
    <style>
        body {
            background-color: lavender;
            font-family: Arial, sans-serif;
            text-align: center;
        }
        h2 {
            margin-top: 20px;
            font-size: 2em;
        }
        form {
            margin-bottom: 20px;
        }
        table {
            width: 60%;
            margin: auto;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
            padding: 10px;
        }
        th {
            background-color: #d3cce3;
        }
        td {
            background-color: white;
        }
        a {
            text-decoration: none;
            color: blue;
        }
    </style>
</head>
<body>
    <h2>My Website</h2>
    <form action="process.php" method="post">
        <input type="text" name="studentId" placeholder="Student ID" required>
        <input type="text" name="firstName" placeholder="First Name" required>
        <input type="text" name="middleInitial" placeholder="Middle Initial" required maxlength="1">
        <input type="text" name="lastName" placeholder="Last Name" required>
        <input type="date" name="dateOfbirth" placeholder="Date of Birth" required>
        <select name="gender" required>
            <option value="">Select Gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
        </select>
        <input type="email" name="emailAddress" placeholder="Email Address" required>
        <input type="tel" name="phoneNumber" placeholder="Phone Number" required>
        <button type="submit" name="submit">Add</button>
    </form>

    <h3>Users List</h3>
    <table>
        <tr>
            <th>Student ID</th>
            <th>First Name</th>
            <th>Middle Initial</th>
            <th>Last Name</th>
            <th>Date of Birth</th>
            <th>Gender</th>
            <th>Email Address</th>
            <th>Phone Number</th>
            <th>Actions</th>
        </tr>
        <?php
        include "db.php";
        $result = $conn->query("SELECT * FROM basic_information");
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['studentId']}</td>
                        <td>{$row['firstName']}</td>
                        <td>{$row['middleInitial']}</td>
                        <td>{$row['lastName']}</td>
                        <td>{$row['dateOfbirth']}</td>
                        <td>{$row['gender']}</td>
                        <td>{$row['emailAddres']}</td>
                        <td>{$row['phoneNumber']}</td>
                        <td>
                            <a href='update.php?id={$row['studentId']}'>Edit</a> | 
                            <a href='delete.php?id={$row['studentId']}' onclick='return confirm(\"Are you sure you want to delete this record?\")'>Delete</a>
                        </td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='9'>No records found</td></tr>";
        }
        $conn->close();
        ?>
    </table>
</body>
</html>