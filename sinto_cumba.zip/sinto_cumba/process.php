<?php
include "db.php";

if (isset($_POST["submit"])) {
    $studentId = $_POST["studentId"];
    $firstName = $_POST["firstName"];
    $middleInitial = $_POST["middleInitial"];
    $lastName = $_POST["lastName"];
    $dateOfbirth = $_POST["dateOfbirth"];
    $gender = $_POST["gender"];
    $emailAddress = $_POST["emailAddress"];
    $phoneNumber = $_POST["phoneNumber"];
    
    $sql = "INSERT INTO basic_information (studentId, firstName, middleInitial, lastName, dateOfbirth, gender, emailAddres, phoneNumber) 
            VALUES ('$studentId', '$firstName', '$middleInitial', '$lastName', '$dateOfbirth', '$gender', '$emailAddress', '$phoneNumber')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Record added successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    header("Location: index.php");
}
?>