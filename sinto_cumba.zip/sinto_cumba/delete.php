<?php
include "db.php";

if (isset($_GET["id"])) {
    $id = $_GET["id"];
    $conn->query("DELETE FROM basic_information WHERE studentId='$id'");
}

header("Location: index.php");
?>