<?php
include "db.php";

if (isset($_GET["id"])) {
    $id = $_GET["id"];
    $result = $conn->query("SELECT * FROM basic_information WHERE studentId='$id'");
    $row = $result->fetch_assoc();
}

if (isset($_POST["update"])) {
    $studentId = $_POST["studentId"];
    $firstName = $_POST["firstName"];
    $middleInitial = $_POST["middleInitial"];
    $lastName = $_POST["lastName"];
    $dateOfbirth = $_POST["dateOfbirth"];
    $gender = $_POST["gender"];
    $emailAddress = $_POST["emailAddress"];
    $phoneNumber = $_POST["phoneNumber"];
    
    $sql = "UPDATE basic_information SET 
            studentId='$studentId',
            firstName='$firstName',
            middleInitial='$middleInitial',
            lastName='$lastName',
            dateOfbirth='$dateOfbirth',
            gender='$gender',
            emailAddres='$emailAddress',
            phoneNumber='$phoneNumber'
            WHERE studentId='$id'";
    
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully!";
    }
    
    header("Location: index.php");
}
?>
<form method="post">
    <input type="text" name="studentId" value="<?php echo $row['studentId']; ?>" required>
    <input type="text" name="firstName" value="<?php echo $row['firstName']; ?>" required>
    <input type="text" name="middleInitial" value="<?php echo $row['middleInitial']; ?>" required>
    <input type="text" name="lastName" value="<?php echo $row['lastName']; ?>" required>
    <input type="text" name="dateOfbirth" value="<?php echo $row['dateOfbirth']; ?>" required>
    <input type="text" name="gender" value="<?php echo $row['gender']; ?>" required>
    <input type="text" name="emailAddress" value="<?php echo $row['emailAddres']; ?>" required>
    <input type="text" name="phoneNumber" value="<?php echo $row['phoneNumber']; ?>" required>
    <button type="submit" name="update">Update</button>
</form>